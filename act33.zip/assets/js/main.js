// create a list of questions and answers
var questionList = [
    {"q": "Is the world round?", "a": false},
    {"q": "Is the sky blue?", "a": true},
    {"q": "Is the grass greener on the other side?", "a": false}
];

// go through each question
for(var i = 0; i < questionList.length; i++){
    console.log(questionList[i]);
    var userAnswer = confirm(questionList[i].q);
    console.log(userAnswer);
    // * Then create code that will ask the user questions, one by one. 
    // The user must answer by hitting OK (for true) or Cancel (for false).

    if(userAnswer === questionList[i].a){
        // * Check the user's answer against the correct answer,
        //  and provide them with an alert telling them if they are right or wrong.
        alert("Correct");
    }
    else{
        alert("Go ask Nick. You are wrong.");
    }
}